import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { CarloanComponent } from './carloan/carloan.component';
import { ContactComponent } from './contact/contact.component';
import { EducationloanComponent } from './educationloan/educationloan.component';
import { GoldloanComponent } from './goldloan/goldloan.component';
import { HomeComponent } from './home/home.component';

import { LoanComponent } from './loan/loan.component';
import { LoginComponent } from './login/login.component';

import { ProfileComponent } from './profile/profile.component';
import { RegisterComponent } from './register/register.component';
import { ServiceComponent } from './service/service.component';
import { VeiwdetailComponent } from './veiwdetail/veiwdetail.component';

const routes: Routes = [
  { path:'', component:HomeComponent},
{ path:'contact', component:ContactComponent},
{ path:'service', component:ServiceComponent},
{ path:'login', component:LoginComponent},
{ path:'register', component:RegisterComponent},
{ path:'loan', component:LoanComponent},
{ path:'carloan', component:CarloanComponent},
{ path:'goldloan', component:GoldloanComponent},
{path:'educationloan', component:EducationloanComponent},
{ path:'about', component:AboutComponent},
{ path:'profile', component:ProfileComponent},
{ path:'veiwdetail/:id', component:VeiwdetailComponent},
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
