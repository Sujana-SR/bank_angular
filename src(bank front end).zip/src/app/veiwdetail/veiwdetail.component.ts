import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-veiwdetail',
  templateUrl: './veiwdetail.component.html',
  styleUrls: ['./veiwdetail.component.css']
})
export class VeiwdetailComponent implements OnInit {

  constructor(private route:ActivatedRoute) { }

  ngOnInit(): void {
    console.log(this.route.snapshot.params['id'])
  }

}
