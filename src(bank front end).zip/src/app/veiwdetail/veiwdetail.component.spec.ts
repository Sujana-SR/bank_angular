import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VeiwdetailComponent } from './veiwdetail.component';

describe('VeiwdetailComponent', () => {
  let component: VeiwdetailComponent;
  let fixture: ComponentFixture<VeiwdetailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VeiwdetailComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(VeiwdetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
