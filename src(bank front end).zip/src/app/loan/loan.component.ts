import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loan',
  templateUrl: './loan.component.html',
  styleUrls: ['./loan.component.css']
})
export class LoanComponent implements OnInit {

  constructor() { }
  amount:number=0;
  amount1:number=0;
  amount2:number=0;

  ngOnInit(): void {
  }
  demo(val1:number,val2:number)
  {
     
   this.amount=(val1*val2*0.04)/100;
    return `${this.amount}`;
  }
  dem(val1:number,val2:number)
  {
     
   this.amount1=(val1*val2*0.07)/100;
    return `${this.amount1}`;
  }
  demo1(val1:number,val2:number)
  {
     
   this.amount2=(val1*val2*0.09)/100;
    return `${this.amount2}`;
  }

}
